package epn.esfot.javahashingexamen;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private ComboBox<String> cmbRol;
    @FXML
    private Button btnIniciar;

    @FXML
    public void initialize() {
        cmbRol.getItems().addAll(
                "Administrador",
                "Cliente",
                "Invitado"
        );
    }

    private static String rol;

    public static String getRol() {
        return rol;
    }

    public static void setRol(String rol) {
        LoginController.rol = rol;
    }

    @FXML
    public void inicio() throws IOException {
        String usuario = txtUsuario.getText().trim();
        String password = txtPassword.getText();
        String rolSeleccionado = cmbRol.getValue();

        if (rolSeleccionado == null) {
            mostrarAlerta("Error de acceso", "Seleccione un rol");
            return;
        }

        if (rolSeleccionado.equals("Invitado")) {
            mostrarAlerta("Aviso", "El rol Invitado no tiene acceso");
            return;
        }

        boolean credencialesValidas = false;

        if (rolSeleccionado.equals("Administrador") &&
                usuario.equals("admin") &&
                password.equals("1234")) {
            credencialesValidas = true;
        } else if (rolSeleccionado.equals("Cliente") &&
                usuario.equals("user") &&
                password.equals("1234")) {
            credencialesValidas = true;
        }

        if (credencialesValidas) {
            setRol(rolSeleccionado);
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(
                    getClass().getResource("registro.fxml")
            );
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Registro de Cliente");
            stage.setScene(scene);
            stage.show();

            Stage stageActual = (Stage) btnIniciar.getScene().getWindow();
            stageActual.close();
        } else {
            mostrarAlerta("Error de acceso", "Credenciales Incorrectas");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}
