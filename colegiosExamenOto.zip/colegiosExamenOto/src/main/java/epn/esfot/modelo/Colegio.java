package epn.esfot.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "colegio")
public class Colegio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String nombre;
    private String ubicacion;
    private String tipo;
    private int num_estudiantes;
    private String director;

    public Colegio() {}

    public Colegio(String nombre, String ubicacion, String tipo, int num_estudiantes, String director) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
        this.num_estudiantes = num_estudiantes;
        this.director = director;
    }

    public Colegio(Integer id, String nombre, String tipo, String ubicacion, int num_estudiantes, String director) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.ubicacion = ubicacion;
        this.num_estudiantes = num_estudiantes;
        this.director = director;
    }

    public Integer getId() {return id;}

    public void setId(Integer id) {this.id = id;}

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public String getUbicacion() {return ubicacion;}

    public void setUbicacion(String ubicacion) {this.ubicacion = ubicacion;}

    public String getTipo() {return tipo;}

    public void setTipo(String tipo) {this.tipo = tipo;}

    public int getNum_estudiantes() {return num_estudiantes;}

    public void setNum_estudiantes(int num_estudiantes) {this.num_estudiantes = num_estudiantes;}

    public String getDirector() {return director;}

    public void setDirector(String director) {this.director = director;}

    @Override
    public String toString() {
        return "Colegio{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", ubicacion='" + ubicacion + '\'' +
                ", tipo='" + tipo + '\'' +
                ", num_estudiantes=" + num_estudiantes +
                ", director='" + director + '\'' +
                '}';
    }
}

