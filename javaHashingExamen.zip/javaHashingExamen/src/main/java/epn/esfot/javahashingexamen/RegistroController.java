package epn.esfot.javahashingexamen;

import epn.esfot.javahashingexamen.modelo.Usuario;
import epn.esfot.javahashingexamen.modelo.UsuarioDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;

public class RegistroController {

    @FXML
    private TextField txtUsuario;
    @FXML
    private TextField txtCorreo;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextField txtDireccion;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private PasswordField txtConfirmPassword;
    @FXML
    private Button btnRegistrar;
    @FXML
    private Button btnCancelar;

    @FXML
    public void registrar() throws IOException {
        String nombre = txtUsuario.getText();
        String correo = txtCorreo.getText();
        String telefono = txtTelefono.getText();
        String direccion = txtDireccion.getText();
        String password = txtPassword.getText();
        String confirm = txtConfirmPassword.getText();

        if (nombre.isEmpty() || correo.isEmpty() || telefono.isEmpty() ||
                direccion.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            mostrarAlerta("Error", "Todos los campos son obligatorios");
            return;
        }

        if (!password.equals(confirm)) {
            mostrarAlerta("Error", "Las contraseñas no coinciden");
            return;
        }

        if (password.length() < 4) {
            mostrarAlerta("Error", "La contraseña debe tener al menos 4 caracteres");
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();
        Usuario existente = dao.buscarPorUsername(nombre);
        if (existente != null) {
            mostrarAlerta("Error", "El usuario '" + nombre + "' ya existe");
            return;
        }

        String hash = BCrypt.hashpw(password, BCrypt.gensalt());

        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombre(nombre);
        nuevoUsuario.setCorreo(correo);
        nuevoUsuario.setTelefono(telefono);
        nuevoUsuario.setDireccion(direccion);
        nuevoUsuario.setPassword(hash);

        boolean registrado = dao.insertar(nuevoUsuario);

        if (registrado) {
            mostrarAlerta("Éxito", "Usuario registrado correctamente");
            limpiarCampos();
            volverALogin();
        } else {
            mostrarAlerta("Error", "No se pudo registrar el usuario");
        }
    }

    @FXML
    public void cancelar() throws IOException {
        volverALogin();
    }

    private void volverALogin() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Login");
        stage.show();

        Stage stageActual = (Stage) btnCancelar.getScene().getWindow();
        stageActual.close();
    }

    private void limpiarCampos() {
        txtUsuario.setText("");
        txtCorreo.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        txtPassword.setText("");
        txtConfirmPassword.setText("");
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}