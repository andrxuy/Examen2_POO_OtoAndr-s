package epn.esfot.javahashingexamen.modelo;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static final String JDBC_URL =
            "jdbc:mysql://localhost:3306/base_de_colegios";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "";

    public Connection conectarMySql(){
        Connection conn = null;
        try{
            conn= DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
            System.out.println("Conectado OK");
        }catch (SQLException ex){
            System.out.println("No pudo conectar" + ex.getMessage());
        }
        return conn;
    }

    public static void main(String[] args) {
        Conexion c = new Conexion();
        c.conectarMySql();
    }
}
