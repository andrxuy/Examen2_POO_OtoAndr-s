package epn.esfot.javahashingexamen.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    private final String SELECT_BY_USERNAME = "SELECT * FROM usuarios WHERE nombre=?";
    private final String INSERT = "INSERT INTO usuarios (nombre, correo, telefono, password, direccion) VALUES (?, ?, ?, ?, ?)";

    public Usuario buscarPorUsername(String username) {
        try (Connection conn = new Conexion().conectarMySql()) {
            PreparedStatement ps = conn.prepareStatement(SELECT_BY_USERNAME);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setNombre(rs.getString("nombre"));
                u.setCorreo(rs.getString("correo"));
                u.setTelefono(rs.getString("telefono"));
                u.setPassword(rs.getString("password"));
                u.setDireccion(rs.getString("direccion"));
                return u;
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar usuario: " + e.getMessage());
        }
        return null;
    }

    public boolean insertar(Usuario usuario) {
        try (Connection conn = new Conexion().conectarMySql()) {
            PreparedStatement ps = conn.prepareStatement(INSERT);
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getTelefono());
            ps.setString(4, usuario.getPassword());
            ps.setString(5, usuario.getDireccion());
            int filas = ps.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar usuario: " + e.getMessage());
            return false;
        }
    }
}
