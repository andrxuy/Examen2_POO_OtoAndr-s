module epn.esfot.javahashingexamen {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jbcrypt;


    opens epn.esfot.javahashingexamen to javafx.fxml;
    exports epn.esfot.javahashingexamen;
    exports epn.esfot.javahashingexamen.modelo;
}