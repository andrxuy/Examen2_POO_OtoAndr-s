package epn.esfot.servicio;
import epn.esfot.modelo.Colegio;
import epn.esfot.modelo.ColegioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ColegioServicio {
    @Autowired
    private ColegioRepository colegioRepository;

    public List<Colegio> listarTodo(){return colegioRepository.findAll();}

    public Optional<Colegio> buscar(Integer id){ return colegioRepository.findById(id);}

    public Colegio insertar(Colegio colegio){  return colegioRepository.save(colegio);}

    public Colegio actualizar(Colegio colegio){ return colegioRepository.save(colegio);
    }

    public void eliminar(Integer id){
        colegioRepository.deleteById(id);}


}

