package epn.esfot;

import epn.esfot.modelo.Colegio;
import epn.esfot.servicio.ColegioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestServicio implements CommandLineRunner {

    @Autowired
    private ColegioServicio colegioServicio;

    public static void main(String[] args) {
        SpringApplication.run(TestServicio.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        for (Colegio p : colegioServicio.listarTodo()) {
            System.out.println(p);
        }
    }
}