package epn.esfot;

import epn.esfot.modelo.Colegio;
import epn.esfot.modelo.ColegioRepository;
import epn.esfot.servicio.ColegioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ColegioController {
    @Autowired
    private ColegioServicio colegioServicio;

    @GetMapping("/examen")
    public String prueba(){return "Examen final java";}

    @GetMapping("/colegio")
    public List<Colegio> obtenerColegios(){ return colegioServicio.listarTodo();}

    @GetMapping("/colegio/{id}")
    public Colegio obtenerColegioPorId(@PathVariable Integer id){ return colegioServicio.buscar(id).orElse(null);}

    @PostMapping("/colegio")
    public Colegio insertarColegio(@RequestBody Colegio colegio) {
        return colegioServicio.insertar(colegio);
    }

    @DeleteMapping("/colegio/{id}")
    public void eliminarColegio(@PathVariable int id) {
        colegioServicio.eliminar(id);
    }

    @PutMapping("/colegio/{id}")
    public Colegio actualizarColegio(@RequestBody Colegio colegio, @PathVariable("id")Integer id) {
        return colegioServicio.actualizar(colegio);
    }
}

