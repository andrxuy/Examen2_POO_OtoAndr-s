package epn.esfot.javahashingexamen;

import epn.esfot.javahashingexamen.modelo.Usuario;
import epn.esfot.javahashingexamen.modelo.UsuarioDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.mindrot.jbcrypt.BCrypt;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private ComboBox<String> cmbRol;
    @FXML
    private Button btnInicio;
    @FXML
    private Button btnRegistro;

    private static String rol;

    public static String getRol() {
        return rol;
    }

    public static void setRol(String rol) {
        LoginController.rol = rol;
    }

    @FXML
    public void initialize() {
        cmbRol.getItems().addAll(
                "Administrador",
                "Cliente",
                "Invitado"
        );
        cmbRol.setValue("Administrador");
    }

    @FXML
    public void irARegistro() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("registro.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Registro de Cliente");
        stage.show();

        Stage stageActual = (Stage) btnInicio.getScene().getWindow();
        stageActual.close();
    }

    @FXML
    public void inicio() throws IOException {
        String usuario = txtUsuario.getText();
        String password = txtPassword.getText();
        String rolSeleccionado = cmbRol.getValue();

        if (rolSeleccionado == null) {
            mostrarAlerta("Error de acceso", "Seleccione un rol");
            return;
        }

        if (!rolSeleccionado.equals("Administrador")) {
            mostrarAlerta("Error de acceso", "Solo el rol Administrador tiene acceso");
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();
        Usuario usuarioEncontrado = dao.buscarPorUsername(usuario);

        if (usuarioEncontrado == null) {
            mostrarAlerta("Error de acceso", "Credenciales Incorrectas");
            return;
        }

        if (!BCrypt.checkpw(password, usuarioEncontrado.getPassword())) {
            mostrarAlerta("Error de acceso", "Credenciales Incorrectas");
            return;
        }

        setRol(rolSeleccionado);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("registro.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Registro de Cliente");
        stage.show();

        Stage stageActual = (Stage) btnInicio.getScene().getWindow();
        stageActual.close();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}